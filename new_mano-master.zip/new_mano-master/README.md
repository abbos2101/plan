# Ma'no
## Ishlatilgan texnalogiyalar
1. MVVM
2. davom etmoqda

## Dastur sxemasi
![Dastur sxemasi](git_images/img_scheme.png)

## Splash Screen/Dastur ishga tushganda shu qismdan o'tadi
![Splash Screen](git_images/img1.jpg)

## Registration Screen/Ro'yxatdan o'tadigan qism
![Registration Screen](git_images/img2.jpg)

## Welcome Screen/Birinchi marta foydalanganda, foydalanuvchi darajasini tekshiradigan oyna
![Welcome Screen](git_images/img3.jpg)

## Content Screen/Darslikning qismlari
![Content Screen](git_images/img4.jpg)

### Bog'lanish uchun
[Telegram](https://t.me/abbos2101)
[Facebook](https://www.facebook.com/abbos.bobomurodov.2101)
