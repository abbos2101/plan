package abbos2101.new_mano

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
