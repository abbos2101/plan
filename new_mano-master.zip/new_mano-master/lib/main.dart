import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:new_mano/screen/screens.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  // SystemChrome.setEnabledSystemUIOverlays(
  //     SystemUiOverlay.values); //to show bottom bar and status bar:
  // SystemChrome.setEnabledSystemUIOverlays(
  //     [SystemUiOverlay.top]); //to hide only bottom bar:
  // SystemChrome.setEnabledSystemUIOverlays(
  //     [SystemUiOverlay.bottom]); //to hide only status bar:
  // SystemChrome.setEnabledSystemUIOverlays([]); //to hide both:
  runApp(LaunchApp());
}

class LaunchApp extends StatefulWidget {
  @override
  _LaunchAppState createState() => _LaunchAppState();
}

class _LaunchAppState extends State<LaunchApp> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light().copyWith(primaryColor: Color(0xFFF9AD08)),
      home: SplashScreen(),
      // home: RegularScreen(1),
    );
  }
}
