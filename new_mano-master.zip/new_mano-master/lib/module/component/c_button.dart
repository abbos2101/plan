import 'package:flutter/material.dart';
import 'components.dart';

class CButton extends StatelessWidget {
  final Key key;
  final double width;
  final double height;
  final Color color;
  final Function onPressed;
  final EdgeInsets margin;
  final double opacity;
  final double circular;
  final Widget child;
  final bool enable;
  final CView visibility;
  final bool showShadow;

  CButton({
    this.key,
    this.width = 100,
    this.height = 60,
    this.color = Colors.orangeAccent,
    this.onPressed,
    this.margin,
    this.opacity = 1,
    this.circular = 0,
    this.enable = true,
    this.child,
    this.visibility = CView.VISIBLE,
    this.showShadow = true,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return _widgetButton();
      case CView.INVISIBLE:
        return Container(key: key, width: width, height: height);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }

  Widget _widgetButton() => Container(
        key: key,
        width: width,
        height: height,
        margin: margin,
        decoration: BoxDecoration(
          color: enable == true
              ? color.withOpacity(opacity)
              : color.withOpacity(opacity * 0.5),
          shape: BoxShape.rectangle,
          borderRadius: BorderRadius.circular(circular),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius:
                  showShadow == true && enable == true ? height * 0.1 : 0,
            ),
          ],
        ),
        child: FlatButton(
          onPressed: enable == true ? onPressed : null,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(circular),
          ),
          child: child ?? _childTmp,
        ),
      );

  Widget _childTmp = Text(
    "ok",
    style: const TextStyle(
        color: const Color(0xFF000000),
        fontWeight: FontWeight.w400,
        fontFamily: "Myriad Pro",
        fontStyle: FontStyle.normal,
        fontSize: 20.0),
  );
}
