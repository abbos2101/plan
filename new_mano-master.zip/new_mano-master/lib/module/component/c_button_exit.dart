import 'package:flutter/material.dart';
import 'components.dart';

class CButtonExit extends StatelessWidget {
  final Key key;
  final EdgeInsets margin;
  final CView visibility;
  final IconData icon;
  final double iconSize;
  final Function onPressed;
  final Color color;

  const CButtonExit({
    this.key,
    this.margin,
    this.visibility = CView.VISIBLE,
    this.icon,
    this.iconSize = 30,
    this.onPressed,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return Padding(
          key: key,
          padding: margin ?? EdgeInsets.all(0),
          child: FloatingActionButton(
            backgroundColor: color ?? Colors.grey[200],
            onPressed: onPressed,
            child:
                icon ?? Icon(Icons.logout, color: Colors.black, size: iconSize),
          ),
        );
      case CView.INVISIBLE:
        return Container(key: key, height: iconSize, width: iconSize);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }
}
