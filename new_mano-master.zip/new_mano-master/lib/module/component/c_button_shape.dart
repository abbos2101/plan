import 'package:flutter/material.dart';
import 'package:polygon_clipper/polygon_border.dart';
import 'components.dart';

class CButtonShape extends StatelessWidget {
  final Key key;
  final CView visibility;
  final Function onPressed;
  final int sides;
  final double size;
  final double width;
  final double height;
  final double rotate;
  final EdgeInsets margin;
  final Color color;
  final bool active;
  final double borderWidth;
  final Widget child;
  final bool showShadow;

  CButtonShape({
    this.key,
    this.visibility = CView.VISIBLE,
    this.onPressed,
    this.sides = 6,
    this.size = 35,
    this.width,
    this.height,
    this.rotate = 90,
    this.margin,
    this.color = Colors.orangeAccent,
    this.active = false,
    this.borderWidth,
    this.child,
    this.showShadow = false,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return _viewShape();
      case CView.INVISIBLE:
        return Container(key: key, width: size, height: size);
      case CView.GONE:
        return Container(key: key);
    }
  }

  Widget _viewShape() => Container(
        width: width,
        height: height ?? size,
        margin: margin,
        decoration: showShadow == true
            ? BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 30,
                  ),
                ],
              )
            : BoxDecoration(),
        child: FlatButton(
          child: child,
          shape: PolygonBorder(
            sides: sides,
            rotate: rotate,
            border: BorderSide(width: borderWidth ?? size / 15, color: color),
          ),
          color: active == true ? color.withOpacity(0.4) : Colors.white,
          disabledColor: active == true ? color.withOpacity(0.4) : Colors.white,
          onPressed: onPressed,
          highlightColor: color.withOpacity(0.3),
          splashColor: color.withOpacity(0.3),
        ),
      );
}
