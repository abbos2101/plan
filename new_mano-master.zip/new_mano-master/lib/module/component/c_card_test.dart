import 'package:flutter/material.dart';
import 'components.dart';

class CCardTest extends StatelessWidget {
  final Key key;
  final CView visibility;
  final String title;
  final String question;
  final Function onPressedTrue;
  final Function onPressedFalse;
  final Color colorTrue;
  final Color colorFalse;
  final double height;
  final bool enableButton;

  CCardTest({
    this.key,
    this.visibility = CView.VISIBLE,
    this.title = "Gap to'g'ri tuzulganmi?",
    this.question = "Savol",
    this.colorTrue = Colors.green,
    this.height = 300,
    this.colorFalse = Colors.red,
    this.onPressedTrue,
    this.onPressedFalse,
    this.enableButton = true,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return widgetCardCustom();
      case CView.INVISIBLE:
        return Container(key: key, height: height);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }

  Widget widgetCardCustom() {
    return Stack(children: <Widget>[
      Container(
        key: key,
        width: double.infinity,
        height: height * 0.45,
        margin: EdgeInsets.only(left: 20, right: 20),
        child: Column(
          children: <Widget>[
            // Expanded(flex: 1, child: _viewTitleText(text: title)),//TODO TITLE
            // _viewDividerCustom(),//TODO DIVIDER
            SizedBox(height: 10),
            Expanded(
              flex: 2,
              child: Container(
                alignment: Alignment.center,
                padding: EdgeInsets.only(left: 20, right: 20),
                child: Text(
                  question,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w400),
                ),
              ),
            ),
            Expanded(
                flex: 2,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        child: _viewButton(
                          enableButton: enableButton,
                          color: colorTrue,
                          text: "To'g'ri",
                          onPressed: onPressedTrue,
                        ),
                      ),
                      Expanded(
                        child: _viewButton(
                          enableButton: enableButton,
                          color: colorFalse,
                          text: "Noto'g'ri",
                          onPressed: onPressedFalse,
                        ),
                      )
                    ],
                  ),
                )),
          ],
        ),
        decoration: _viewBoxDecoration,
      ),
      _viewFolderIcon(),
    ]);
  }

  Widget _viewButton({
    Color color = Colors.yellow,
    Function onPressed,
    EdgeInsets margin,
    double circular = 0,
    bool enableButton = true,
    String text = "",
  }) =>
      CButton(
        circular: circular,
        height: height * 0.1,
        enable: enableButton,
        margin: margin ?? EdgeInsets.all(10),
        color: color,
        onPressed: onPressed,
        child: Text(
          "$text",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
      );

  Widget _viewFolderIcon({
    IconData iconData = Icons.folder,
    Color iconColor = Colors.orangeAccent,
  }) =>
      Padding(
        padding: EdgeInsets.only(bottom: height * 0.20),
        child: Align(
            alignment: Alignment.bottomRight,
            child: Icon(iconData, color: iconColor, size: height * 0.15)),
      );

  Widget _viewTitleText({
    String text = "Gap to'g'ri tuzilganmi?",
    double fontSize = 20,
    EdgeInsets margin,
  }) =>
      Padding(
        padding: margin ?? EdgeInsets.all(16),
        child: Text(text, style: TextStyle(fontSize: fontSize)),
      );

  Widget _viewDividerCustom({EdgeInsets margin, double height = 2}) =>
      Container(
        color: Colors.black,
        width: double.infinity,
        height: height,
        margin: margin ?? EdgeInsets.only(left: 20, right: 20),
      );

  BoxDecoration _viewBoxDecoration = BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(10),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.2),
        spreadRadius: 5,
        blurRadius: 7,
        offset: Offset(0, 1),
      ),
    ],
  );
}
