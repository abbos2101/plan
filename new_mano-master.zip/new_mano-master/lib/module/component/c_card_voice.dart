import 'package:flutter/material.dart';
import 'components.dart';

class CCardVoice extends StatelessWidget {
  final Key key;
  final double width;
  final double height;
  final String text;
  final Function onPressed;
  final bool answer;
  final EdgeInsets margin;
  final double circular;
  final CView visibility;

  const CCardVoice({
    this.key,
    this.width,
    this.height,
    this.text = "",
    this.onPressed,
    this.answer = true,
    this.margin,
    this.circular = 0,
    this.visibility = CView.VISIBLE,
  });

  @override
  Widget build(BuildContext context) {
    Color colorTrue = Colors.green;
    Color colorFalse = Colors.red;
    String titleTrue = "To'g'ri";
    String titleFalse = "No'to'gri";

    switch (visibility) {
      case CView.VISIBLE:
        return Stack(
          children: <Widget>[
            Container(
              key: key,
              alignment: Alignment.center,
              width: width,
              height: height,
              margin: margin,
              child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                Text(
                  answer == true ? titleTrue : titleFalse,
                  style: TextStyle(
                    fontSize: 25,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  text,
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ]),
              decoration: BoxDecoration(
                  color: answer == true ? colorTrue : colorFalse,
                  borderRadius: BorderRadius.all(Radius.circular(circular))),
            ),
            Container(
              alignment: Alignment.topRight,
              margin: EdgeInsets.only(top: 10, right: 20),
              child: FlatButton(
                minWidth: 50,
                height: 50,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50)),
                onPressed: onPressed,
                child: Icon(
                  Icons.volume_up,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
          ],
        );

      case CView.INVISIBLE:
        return Container(key: key, width: width, height: height);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }
}
