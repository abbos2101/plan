import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CExitAppDialog extends StatelessWidget {
  final Key key;
  final Widget child;
  final bool onlyOnExit;

  const CExitAppDialog({this.key, this.child, this.onlyOnExit = true});

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        key: key,
        child: child,
        onWillPop: () {
          if (Navigator.canPop(context)) {
            Navigator.pop(context);
            return null;
          }
          return showDialog(
              context: context,
              barrierDismissible: true,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text("Tasdiqlang"),
                  content: Text("Dasturdan chiqmoqchimisiz?"),
                  actions: <Widget>[
                    FlatButton(
                      child: Text("Ha"),
                      onPressed: () => SystemNavigator.pop(),
                    ),
                    FlatButton(
                      child: Text("Yo'q"),
                      onPressed: () => Navigator.of(context).pop(),
                    )
                  ],
                );
              });
        });
  }
}
