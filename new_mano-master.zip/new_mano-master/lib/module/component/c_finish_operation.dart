import 'package:flutter/material.dart';

class CFinishOperationDialog extends StatelessWidget {
  final Key key;
  final Widget child;
  final String title;
  final String message;
  final Function onPressedYes;
  final Function onPressedNo;

  const CFinishOperationDialog({
    this.key,
    this.child,
    this.title = "",
    this.message = "",
    this.onPressedYes,
    this.onPressedNo,
  });

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      key: key,
      child: child,
      onWillPop: () => showMyDialog(context),
    );
  }

  showMyDialog(BuildContext context) => showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            FlatButton(
              child: Text("Ha"),
              onPressed: onPressedYes,
            ),
            FlatButton(
              child: Text("Yo'q"),
              onPressed: () => onPressedNo ?? Navigator.of(context).pop(),
            )
          ],
        );
      });
}
