import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'components.dart';

class CImageCache extends StatefulWidget {
  final Key key;
  final CView visibility;
  final String imageUrl;
  final Map<String, String> httpHeaders;
  final EdgeInsets margin;
  final double circular;

  const CImageCache({
    this.key,
    this.visibility = CView.VISIBLE,
    this.imageUrl = "",
    this.httpHeaders,
    this.margin,
    this.circular = 20,
  });

  @override
  _CImageCacheState createState() => _CImageCacheState();
}

class _CImageCacheState extends State<CImageCache> {
  DecorationImage decorationImage;

  @override
  void initState() {
    _getFile(widget.imageUrl, headers: widget.httpHeaders);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    switch (widget.visibility) {
      case CView.VISIBLE:
        return Container(
          margin: widget.margin,
          child: CLoading(
            width: double.infinity,
            height: double.infinity,
            color: Colors.blue,
            visibility: decorationImage == null && widget.imageUrl != ""
                ? CView.VISIBLE
                : CView.INVISIBLE,
          ),
          decoration: BoxDecoration(
            image: decorationImage, //DecorationImage(fit: BoxFit.fill),
            // fileImage != null
            //     ? FileImage(fileImage)
            //     : AssetImage("assets/item_card.png")),
            borderRadius: BorderRadius.circular(widget.circular),
          ),
        );
      case CView.INVISIBLE:
        return Container(key: widget.key);
      case CView.GONE:
        return Container(key: widget.key);
    }
  }

  Future<void> _getFile(
    String fileUrl, {
    Map<String, String> headers,
    bool isCached = true,
  }) async {
    if (fileUrl.isEmpty) return;
    String fileName = fileUrl.substring(fileUrl.lastIndexOf("/") + 1);
    String filePath =
        (await getApplicationDocumentsDirectory()).path + "/$fileName";
    File file = File(filePath);

    if (isCached == true && await file.exists() == true) {
      decorationImage =
          DecorationImage(image: FileImage(file), fit: BoxFit.fill);
      onChanged();
      return;
    }

    try {
      http.Response response = await http.get(fileUrl, headers: headers);
      if (response.statusCode == 200) {
        Uint8List body = response.bodyBytes;
        if (body != null) {
          await file.writeAsBytes(body);
          decorationImage =
              DecorationImage(image: FileImage(file), fit: BoxFit.fill);
          onChanged();
          return;
        }
      }
    } catch (e) {}
    decorationImage = null;
    onChanged();
    return;
  }

  void onChanged() => setState(() {});
}
