import 'package:flutter/material.dart';
import 'components.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class CLoading extends StatelessWidget {
  final Key key;
  final CView visibility;
  final double size;
  final double width;
  final double height;
  final Color color;
  final EdgeInsets margin;

  const CLoading({
    this.key,
    this.visibility = CView.VISIBLE,
    this.size = 40,
    this.width,
    this.height,
    this.color = Colors.orangeAccent,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return Container(
          width: width,
          height: height,
          margin: margin ?? EdgeInsets.all(0),
          child: SpinKitFadingCircle(key: key, color: color, size: size),
        );
      case CView.INVISIBLE:
        return Container(key: key, width: width, height: height);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }
}
