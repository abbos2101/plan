import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'components.dart';
import 'package:new_mano/module/util/const.dart' as cons;

class CPageItem extends StatelessWidget {
  final Key key;
  final CView visibility;
  final double width;
  final double height;
  final EdgeInsets margin;
  final double circular;
  final String imageUrl;
  final String textTitle;
  final String textLesson;
  final String textDescription;
  final Function onPressed;
  final int progress; //[0, 1, 2]

  const CPageItem({
    this.key,
    this.visibility = CView.VISIBLE,
    this.width,
    this.height,
    this.margin,
    this.circular = 30,
    this.imageUrl = "",
    this.textTitle = "",
    this.textLesson = "",
    this.textDescription = "",
    this.onPressed,
    this.progress = -1,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return _widgetItem();
      case CView.INVISIBLE:
        return Container(key: key, width: width, height: height);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }

  Widget _widgetItem() => Container(
        width: width,
        height: height,
        margin: margin,
        child: Column(
          children: <Widget>[
            Expanded(
              flex: 2,
              child: CImageCache(
                margin: EdgeInsets.only(bottom: 10),
                imageUrl: imageUrl,
                circular: circular,
              ),
            ),
            Expanded(flex: 3, child: _widgetItemCard()),
          ],
        ),
      );

  Widget _widgetItemCard() => Stack(children: <Widget>[
        _widgetItemBody(),
        Container(
          alignment: Alignment.center,
          child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                CButtonShape(
                  width: cons.width * 0.2,
                  size: cons.width * 0.2,
                  active: progress >= 0 ? true : false,
                  margin: EdgeInsets.only(top: cons.width * 0.25),
                ),
                CButtonShape(
                  width: cons.width * 0.2,
                  size: cons.width * 0.2,
                  active: progress >= 1 ? true : false,
                  margin: EdgeInsets.only(top: cons.width * 0.05),
                ),
                CButtonShape(
                  width: cons.width * 0.2,
                  size: cons.width * 0.2,
                  active: progress >= 2 ? true : false,
                  margin: EdgeInsets.only(top: cons.width * 0.25),
                ),
              ]),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: _widgetItemButtonStart(),
        ),
      ]);

  Widget _widgetItemButtonStart() {
    double size = cons.width * 0.18;
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.orangeAccent.withOpacity(0.8),
            spreadRadius: 5,
            blurRadius: 5,
          ),
        ],
      ),
      child: FlatButton(
        minWidth: size,
        height: size,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(size),
        ),
        onPressed: onPressed,
        child: Text(
          "Start",
          style: TextStyle(fontSize: size * 0.22),
        ),
      ),
    );
  }

  Widget _widgetItemBody() => Container(
        margin: EdgeInsets.only(bottom: cons.width * 0.06),
        width: double.infinity,
        decoration: BoxDecoration(
            image: DecorationImage(
          fit: BoxFit.fill,
          image: AssetImage("assets/item_background.png"),
        )),
        child: Column(
          children: <Widget>[
            CText(
              textTitle.trim(),
              style: TextStyle(
                  fontWeight: FontWeight.bold, fontSize: cons.height * 0.026),
              margin: EdgeInsets.only(top: cons.height * 0.01),
            ),
            CText(textLesson,
                style: TextStyle(
                  fontSize: cons.height * 0.026,
                  fontWeight: FontWeight.bold,
                )),
            CText(textDescription.trim(),
                width: double.infinity,
                alignment: Alignment.center,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: cons.height * 0.023))
          ],
        ),
      );
}
