import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'components.dart';

class CPageProgress extends StatelessWidget {
  final Key key;
  final CView visibility;
  final double width;
  final double height;
  final EdgeInsets margin;
  final ScrollController controller;
  final EdgeInsets itemMargin;
  final int itemIndex;
  final Color itemColor;
  final int itemCount;
  final double itemSize;

  const CPageProgress({
    this.key,
    this.visibility = CView.VISIBLE,
    this.width,
    this.height,
    this.margin,
    this.controller,
    this.itemMargin,
    this.itemIndex = 0,
    this.itemColor = Colors.black38,
    this.itemCount = 0,
    this.itemSize = 15,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return Container(
          key: key,
          alignment: Alignment.center,
          margin: margin,
          child: ListView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            controller: controller,
            itemCount: itemCount,
            itemBuilder: (context, index) {
              return Container(
                margin: itemMargin,
                width: itemSize,
                decoration: BoxDecoration(
                    color: index != itemIndex
                        ? Colors.white
                        : itemColor.withOpacity(0.4),
                    shape: BoxShape.circle,
                    border:
                        Border.all(width: itemSize * 0.15, color: itemColor)),
              );
            },
          ),
        );
      case CView.INVISIBLE:
        return SizedBox(key: key, width: itemSize, height: itemSize);
      case CView.GONE:
        return SizedBox(key: key);
    }
  }
}
