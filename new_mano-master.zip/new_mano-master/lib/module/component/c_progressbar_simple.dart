import 'package:flutter/material.dart';

class CProgressBarSimple extends StatelessWidget {
  final Key key;
  final double width;
  final double height;
  final int max;
  final int progress;
  final Color colorActive;
  final Color colorPassive;
  final Color colorBackground;
  final EdgeInsets margin;
  final EdgeInsets padding;

  const CProgressBarSimple({
    this.key,
    this.width,
    this.height = 15,
    this.max = 10,
    this.progress = 0,
    this.colorActive = Colors.orangeAccent,
    this.colorPassive = Colors.black26,
    this.colorBackground = Colors.white,
    this.margin,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      padding: padding,
      margin: margin,
      color: colorBackground,
      child: Row(
        children: [
          Expanded(
              flex: progress,
              child: Container(
                height: height,
                color: colorActive,
              )),
          Expanded(
              flex: max - progress,
              child: Container(
                height: height,
                color: colorPassive,
              )),
        ],
      ),
    );
  }
}
