import 'package:flutter/material.dart';
import 'components.dart';

class CRegularTest extends StatelessWidget {
  final Key key;
  final CRegularChild regularChild;
  final double circular;
  final EdgeInsets margin;
  final Function onPressedAll;
  final Function onPressedCheck;
  final bool answer;

  CRegularTest({
    this.key,
    this.regularChild,
    this.circular = 10,
    this.margin,
    this.onPressedAll,
    this.onPressedCheck,
    this.answer,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Column(children: [
        CText(
          "Iborani to'plang",
          width: double.infinity,
          margin: EdgeInsets.only(bottom: 20),
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 25,
          ),
        ),
        Row(
          children: [
            Icon(
              Icons.message,
              color: Colors.orangeAccent,
              size: 50,
            ),
            CText(regularChild.text,
                margin: EdgeInsets.only(left: 10),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ],
        ),
        Container(
          height: 50,
          margin: EdgeInsets.only(top: 20, left: 20),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: regularChild.wordsCheck.length,
            itemBuilder: (context, index) {
              CRegularWordsChild child = regularChild.wordsCheck[index];
              if (child.isActive == true) return Container();
              return _itemCheck(
                index: index,
                color: child.color,
                text: child.text,
                circular: circular,
                margin: margin,
              );
            },
          ),
        ),
        Expanded(child: Container()),
        Container(
          alignment: Alignment.center,
          width: double.infinity,
          height: 50,
          child: answer != null
              ? Container(height: 50)
              : ListView.builder(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemCount: regularChild.wordsAll.length,
                  itemBuilder: (context, index) {
                    CRegularWordsChild child = regularChild.wordsAll[index];
                    return _itemAll(
                      index: index,
                      color: child.color,
                      isActive: child.isActive,
                      text: child.text,
                      circular: circular,
                      margin: margin,
                    );
                  },
                ),
        ),
        Expanded(
            child: CCardVoice(
          circular: 20,
          answer: answer,
          visibility: answer == null ? CView.GONE : CView.VISIBLE,
        )),
      ]),
    );
  }

  String _stringMin(String s) {
    String t = "";
    if (s.length <= 2)
      for (int i = 0; i < s.length + 1; i++) t += " ";
    else
      for (int i = 0; i < s.length + 5; i++) t += " ";
    return t;
  }

  Widget _itemCheck({
    int index,
    Color color,
    String text,
    double circular = 10,
    EdgeInsets margin,
  }) =>
      Padding(
        padding: margin ?? EdgeInsets.all(3),
        child: FlatButton(
          onPressed: () => onPressedCheck(index),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(circular)),
          minWidth: 25,
          color: color,
          child: Text(
            text,
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
        ),
      );

  Widget _itemAll({
    int index,
    Color color,
    String text,
    bool isActive = true,
    double circular = 10,
    EdgeInsets margin,
  }) =>
      Padding(
        padding: margin ?? EdgeInsets.all(3),
        child: FlatButton(
          onPressed: () => onPressedAll(index),
          minWidth: 25,
          shape: isActive == true
              ? RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(circular))
              : RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(circular),
                  side: BorderSide(width: 3, color: Colors.grey[500])),
          color: isActive == true ? color : Colors.grey[300],
          child: Text(
            isActive == true ? text : _stringMin(text),
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
        ),
      );
}

class CRegularChild {
  List<CRegularWordsChild> wordsAll;
  final List<CRegularWordsChild> wordsCheck;
  final String text;
  final String answer;

  CRegularChild({this.wordsAll, this.wordsCheck, this.text, this.answer}) {
    this.wordsAll = CRegularWordsChild.toRandomList(wordsAll);
  }
}

class CRegularWordsChild {
  final Color color;
  final String text;
  bool isActive;

  CRegularWordsChild({
    this.color = Colors.grey,
    this.text = "",
    this.isActive = true,
  });

  static List<CRegularWordsChild> toRandomList(List<CRegularWordsChild> list) {
    //Random Number List
    List<int> tmp = [];
    for (int i = 0; i < list.length; i++) tmp.add(i);
    tmp.shuffle();
    //Random Child
    List<CRegularWordsChild> random = [];
    for (int i = 0; i < list.length; i++) random.add(list[tmp[i]]);
    return random;
  }
}
