import 'package:flutter/material.dart';
import 'components.dart';

class CText extends StatelessWidget {
  final Key key;
  final String text;
  final CView visibility;
  final TextStyle style;
  final TextAlign textAlign;
  final Alignment alignment;
  final int maxLines;
  final bool softWrap;
  final EdgeInsets margin;
  final EdgeInsets padding;
  final double width;
  final double height;

  const CText(
    this.text, {
    this.key,
    this.visibility = CView.VISIBLE,
    this.style,
    this.textAlign,
    this.alignment,
    this.maxLines,
    this.softWrap,
    this.margin,
    this.padding,
    this.width,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return Container(
          alignment: alignment,
          width: width,
          height: height,
          key: key,
          margin: margin,
          padding: padding,
          child: Text(text, style: style ?? TextStyle(fontSize: 25)),
        );
      case CView.INVISIBLE:
        return Container(key: key);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }
}
