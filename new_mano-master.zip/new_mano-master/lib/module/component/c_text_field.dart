import 'package:flutter/material.dart';
import 'package:new_mano/module/component/components.dart';

class CTextField extends StatelessWidget {
  final Key key;
  final TextStyle style;
  final int maxLines;
  final TextAlign textAlign;
  final TextEditingController controller;
  final bool obscureText;
  final bool readOnly;
  final String hint;
  final EdgeInsets margin;
  final EdgeInsets contentPadding;
  final Function onChanged;
  final TextCapitalization textCapitalization;
  final CView visibility;

  const CTextField({
    this.key,
    this.style,
    this.maxLines,
    this.textAlign = TextAlign.start,
    this.controller,
    this.obscureText = false,
    this.readOnly = false,
    this.hint = "",
    this.margin,
    this.contentPadding,
    this.onChanged,
    this.textCapitalization = TextCapitalization.none,
    this.visibility = CView.VISIBLE,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return _widgetTextField();
      case CView.INVISIBLE:
        return Container(key: key);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }

  Widget _widgetTextField() => Padding(
        padding: margin ?? EdgeInsets.all(0),
        child: TextField(
            key: key,
            style: style,
            maxLines: obscureText == false ? maxLines : 1,
            textAlign: textAlign,
            readOnly: readOnly,
            textCapitalization: textCapitalization,
            onChanged: (value) => onChanged(value),
            controller: controller,
            obscureText: obscureText,
            decoration: InputDecoration(
              fillColor: Colors.transparent,
              filled: true,
              hintText: hint,
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: Color.fromRGBO(196, 195, 200, 1),
                  width: 1.0,
                ),
              ),
              border: OutlineInputBorder(),
              contentPadding:
                  contentPadding ?? EdgeInsets.only(left: 10, right: 10),
            )),
      );
}
