import 'package:flutter/material.dart';
import 'components.dart';

class CVisible extends StatelessWidget {
  final key;
  final double width;
  final double height;
  final Widget child;
  final CView visibility;
  final EdgeInsets margin;

  const CVisible({
    this.key,
    this.width = 100,
    this.height = 50,
    this.child,
    this.visibility = CView.VISIBLE,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    switch (visibility) {
      case CView.VISIBLE:
        return Padding(
          key: key,
          padding: margin ?? EdgeInsets.all(0),
          child: child,
        );
      case CView.INVISIBLE:
        return Container(key: key, width: width, height: height);
      case CView.GONE:
        return Container(key: key, width: 0, height: 0);
    }
  }
}
