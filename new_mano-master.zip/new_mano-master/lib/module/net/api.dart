import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'router.dart' as rourter;
import 'package:new_mano/module/pref/main_pref.dart' as pref;
import 'model/models.dart';
export 'model/models.dart';

///***********Auth
Future<bool> onLogin({String username = "", String password = ""}) async {
  if (username.isEmpty || password.isEmpty) return false;

  Map<String, String> params = Map();
  params['"username"'] = '"$username"';
  params['"password"'] = '"$password"';
  Response response = await rourter.request(
    rourter.Method.login,
    params: params,
  );

  if (response.success == false) return false;
  await pref.setToken(response.message);
  await pref.setHasUser(true);
  return response.success;
}

Future<bool> onSignUp({
  String firstname = "",
  String lastname = "",
  String username = "",
  String password = "",
  String confirm_password = "",
}) async {
  if (firstname.isEmpty ||
      lastname.isEmpty ||
      username.isEmpty ||
      password.isEmpty ||
      confirm_password.isEmpty) return false;

  Map<String, String> params = Map();
  params['"firstname"'] = '"$firstname"';
  params['"lastname"'] = '"$lastname"';
  params['"username"'] = '"$username"';
  params['"password"'] = '"$password"';
  params['"confirm_password"'] = '"$confirm_password"';

  Response response =
      await rourter.request(rourter.Method.signup, params: params);

  if (response.success == false) return false;
  await pref.setToken(response.message);
  await pref.setHasUser(true);
  return response.success;
}

///***********EntryQuestions
Future<List<LevelModel>> onGetLevelList() async =>
    (await rourter.request(rourter.Method.level)).toLevelList();

///***********EntryQuestions
Future<List<EntryModel>> onGetEntryQuestions(
  int id, {
  bool isRandom = true,
}) async {
  Map<String, String> params = Map();
  params["id"] = "$id";
  Response response = await rourter.request(
    rourter.Method.entryTests,
    params: params,
  );
  return isRandom == true
      ? response.toEntryListRandom()
      : response.toEntryList();
}

///***********WordSection
Future<List<WordSectionModel>> onGetWordSection(int level,
    {bool isRandom = true}) async {
  Map<String, String> params = Map();
  params["id"] = "$level";
  Response response = await rourter.request(
    rourter.Method.word_section,
    params: params,
  );
  List<WordSectionModel> list = isRandom == true
      ? response.toWordSectionListRandom()
      : response.toWordSectionList();
  for (int i = 0; i < list.length; i++) {
    await onDownloadFile(
        rourter.Method.download_audio, list[i].correctWord.soundName);
    await onDownloadFile(
        rourter.Method.download_image, list[i].correctWord.imageName);
  }
  return list;
}

Future<bool> onDownloadFile(rourter.Method method, String name) async {
  if ((name ?? "").isEmpty) return false;
  String filePath = (await getApplicationDocumentsDirectory()).path + "/$name";
  File file = File(filePath);
  if (await file.exists() == true) return true;

  Map<String, String> params = Map();
  params["name"] = "$name";
  Response response = await rourter.request(method, params: params);

  if (response.success == false) return false;
  if (response.object == null) return false;
  await file.writeAsBytes(response.object);
  return true;
}

Future<bool> onPlayMusic(String name) async {
  if ((name ?? "").isEmpty) return false;
  if (name.contains(".mp3") == false) return false;
  String filePath = (await getApplicationDocumentsDirectory()).path + "/$name";
  if (await onDownloadFile(rourter.Method.download_audio, name) == false)
    return false;

  try {
    AudioPlayer audioPlayer = AudioPlayer();
    await audioPlayer.play(filePath, isLocal: true);
    return true;
  } catch (e) {
    return false;
  }
}

///****************
Future<List<LessonModel>> onGetLessons() async {
  Map<String, String> params = Map();
  params["id"] = "${await pref.level}";
  Response response = await rourter.request(
    rourter.Method.lesson,
    params: params,
  );
  return response.toLessonList();
}
