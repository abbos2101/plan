class LessonModel {
  LessonModel({
    this.name,
    this.id,
    this.description,
    this.blockName,
  });

  String name;
  int id;
  String description;
  String blockName;

  factory LessonModel.fromJson(Map<String, dynamic> json) => LessonModel(
        name: json["name"],
        id: json["id"],
        description: json["description"],
        blockName: json["blockName"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "id": id,
        "description": description,
        "blockName": blockName,
      };
}
