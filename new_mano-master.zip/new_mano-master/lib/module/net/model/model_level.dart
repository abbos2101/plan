class LevelModel {
  final int id;
  final String name;

  const LevelModel(this.id, this.name);

  factory LevelModel.fromJson(Map<String, dynamic> json) =>
      LevelModel(json["id"], json["name"]);
}
