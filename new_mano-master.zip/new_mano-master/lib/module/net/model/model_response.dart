import 'models.dart';

class Response {
  final String message;
  final bool success;
  final dynamic object;
  final int httpStatusCode;

  const Response({
    this.success,
    this.message,
    this.object,
    this.httpStatusCode,
  });

  factory Response.fromJson(Map<String, dynamic> json, int httpStatusCode) =>
      Response(
        success: json["success"],
        message: json["message"],
        object: json["object"],
        httpStatusCode: httpStatusCode,
      );

  ///************
  List<EntryModel> toEntryList() {
    List<EntryModel> list = [];
    try {
      for (int i = 0; i < (object as List).length; i++) {
        list.add(EntryModel.fromJson(object[i]));
        if (i == 10) break;
      }
    } catch (e) {}
    return list;
  }

  List<EntryModel> toEntryListRandom() {
    List<EntryModel> list = [];
    List<int> rand = [];
    try {
      for (int i = 0; i < (object as List).length; i++) {
        rand.add(i);
        if (i == 9) break;
      }
      rand.shuffle();
      for (int i = 0; i < (object as List).length; i++) {
        list.add(EntryModel.fromJson(object[rand[i]]));
        if (i == 9) break;
      }
    } catch (e) {}
    return list;
  }

  ///************
  List<WordSectionModel> toWordSectionList() => List<WordSectionModel>.from(
      object.map((x) => WordSectionModel.fromJson(x)));

  List<WordSectionModel> toWordSectionListRandom() {
    List<WordSectionModel> list = [];
    List<int> rand = [];
    try {
      for (int i = 0; i < (object as List).length; i++) rand.add(i);
      rand.shuffle();
      for (int i = 0; i < (object as List).length; i++)
        list.add(WordSectionModel.fromJson(object[rand[i]]));
    } catch (e) {}
    return list;
  }

  ///************
  List<LevelModel> toLevelList() =>
      List<LevelModel>.from(object.map((x) => LevelModel.fromJson(x)));

  List<LessonModel> toLessonList() =>
      List<LessonModel>.from(object.map((x) => LessonModel.fromJson(x)));
}
