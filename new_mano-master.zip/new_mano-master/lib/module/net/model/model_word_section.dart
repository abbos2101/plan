class WordSectionModel {
  WordSectionModel({
    this.id,
    this.correctWord,
    this.incorrectWord,
  });

  int id;
  CorrectWord correctWord;
  CorrectWord incorrectWord;

  factory WordSectionModel.fromJson(Map<String, dynamic> json) =>
      WordSectionModel(
        id: json["id"],
        correctWord: CorrectWord.fromJson(json["correctWord"]),
        incorrectWord: CorrectWord.fromJson(json["incorrectWord"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "correctWord": correctWord.toJson(),
        "incorrectWord": incorrectWord.toJson(),
      };
}

class CorrectWord {
  CorrectWord({
    this.id,
    this.ru,
    this.uz,
    this.imageName,
    this.soundName,
    this.example,
    this.gender,
  });

  int id;
  String ru;
  String uz;
  String imageName;
  String soundName;
  String example;
  String gender;

  factory CorrectWord.fromJson(Map<String, dynamic> json) => CorrectWord(
        id: json["id"],
        ru: json["ru"],
        uz: json["uz"],
        imageName: json["image_name"],
        soundName: json["sound_name"],
        example: json["example"],
        gender: json["gender"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "ru": ru,
        "uz": uz,
        "image_name": imageName,
        "sound_name": soundName,
        "example": example,
        "gender": gender,
      };
}
