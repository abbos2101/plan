import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:new_mano/module/pref/main_pref.dart' as pref;
import 'model/model_response.dart';

enum _MethodType { GET, POST }
enum Method {
  login,
  signup,
  level,
  entryTests,
  word_section,
  lesson,
  download_audio,
  download_image,
}

_MethodType _getMethodType(Method method) {
  switch (method) {
    case Method.login:
    case Method.signup:
      return _MethodType.POST;

    case Method.entryTests:
    case Method.level:
    case Method.word_section:
    case Method.lesson:
    case Method.download_audio:
    case Method.download_image:
      return _MethodType.GET;
  }
}

String _getUrl(Method method) {
  String baseUrl = "http://185.16.40.113:8080/api";
  switch (method) {
    case Method.login:
      return "$baseUrl/auth/login";
    case Method.signup:
      return "$baseUrl/auth/signup";
    case Method.level:
      return "$baseUrl/level";
    case Method.entryTests:
      return "$baseUrl/entry-question/level/{id}";
    case Method.word_section:
      return "$baseUrl/wordSection/lesson/{id}";
    case Method.lesson:
      return "$baseUrl/lesson/{id}";
    case Method.download_audio:
      return "$baseUrl/download/audio/{name}";
    case Method.download_image:
      return "$baseUrl/download/image/{name}";
  }
}

Future<String> _getToken() async => await pref.token;

Future<Map<String, String>> _getHeader(Method method) async {
  switch (method) {
    default:
      Map<String, String> headers = Map();
      headers['Content-Type'] = 'application/json';
      headers['token'] = await _getToken();
      return headers;
  }
}

int _getTimeout(Method method) {
  switch (method) {
    default:
      return 60;
  }
}

Future<Response> request(
  Method method, {
  Map<String, String> headers,
  Map<String, String> params,
}) async {
  ///Set parameters
  String url = _getUrl(method);
  int timeout = _getTimeout(method);
  _MethodType methodType = _getMethodType(method);
  Map<String, String> newHeader = Map();
  newHeader.addAll(await _getHeader(method));
  if (headers != null) newHeader.addAll(headers);
  if (methodType == _MethodType.GET && params != null)
    params.forEach((key, value) => url = url.replaceAll("{$key}", value));

  ///Return
  if (methodType == _MethodType.GET)
    return await _requestGet(
      url: url,
      headers: newHeader,
      timeOut: timeout,
      method: method,
    );
  if (methodType == _MethodType.POST)
    return await _requestPost(
      url: url,
      headers: newHeader,
      params: params,
      timeOut: timeout,
    );
}

Future<Response> _requestGet({
  String url,
  int timeOut,
  Map<String, String> headers,
  Method method,
}) async {
  try {
    http.Response response = await http
        .get(url, headers: headers)
        .timeout(Duration(seconds: timeOut));

    if (response == null)
      return Response(success: false, httpStatusCode: 0, message: null);
    if (response.bodyBytes == null)
      return Response(success: false, httpStatusCode: 0, message: null);
    if (method == Method.download_audio || method == Method.download_image)
      return Response(
        success: response.statusCode == 200 ? true : false,
        httpStatusCode: response.statusCode,
        object: response.bodyBytes,
      );

    Map<String, dynamic> jsonData =
        convert.jsonDecode(convert.utf8.decode(response.bodyBytes));
    return Response.fromJson(jsonData, response.statusCode);
  } catch (e) {
    return Response(success: false, httpStatusCode: 0, message: "$e");
  }
}

Future<Response> _requestPost({
  String url,
  int timeOut,
  Map<String, String> headers,
  Map<String, String> params,
}) async {
  try {
    http.Response response = await http
        .post(url, headers: headers, body: params.toString())
        .timeout(Duration(seconds: timeOut));

    Map<String, dynamic> jsonData;
    if (response.bodyBytes != null)
      jsonData = convert.jsonDecode(convert.utf8.decode(response.bodyBytes));
    return Response.fromJson(jsonData, response.statusCode);
  } catch (e) {
    return Response(success: false, httpStatusCode: 0, message: "$e");
  }
}
