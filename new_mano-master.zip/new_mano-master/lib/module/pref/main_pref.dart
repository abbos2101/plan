import 'package:shared_preferences/shared_preferences.dart';

///Keys
enum Keys {
  hasUser,
  passedWelcome,
  token,
  passedImageTest,
  level,
  levelName,
  login,
  password,
}

///Public functions
Future<bool> get hasUser async => (await _getValue(Keys.hasUser)) ?? false;

Future<void> setHasUser(bool value) async =>
    await _setValue(Keys.hasUser, value);
//**
Future<bool> get passedWelcome async =>
    (await _getValue(Keys.passedWelcome)) ?? false;

Future<void> setPassedWelcome(bool value) async =>
    await _setValue(Keys.passedWelcome, value);

Future<String> get login async => (await _getValue(Keys.login)) ?? "";

Future<void> setLogin(String value) async => await _setValue(Keys.login, value);
//**
Future<String> get password async => (await _getValue(Keys.password)) ?? "";

Future<void> setPassword(String value) async =>
    await _setValue(Keys.password, value);
//**
Future<String> get token async => (await _getValue(Keys.token)) ?? "";

Future<void> setToken(String value) async => await _setValue(Keys.token, value);
//**
Future<int> get level async => (await _getValue(Keys.level)) ?? 1;

Future<void> setLevel(int value) async => await _setValue(Keys.level, value);
//**
Future<String> get levelName async => (await _getValue(Keys.levelName)) ?? "";

Future<void> setLevelName(String value) async =>
    await _setValue(Keys.levelName, value);
//**
///Private functions
Future<void> _setValue(dynamic key, dynamic value) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  if (value is bool)
    prefs.setBool("$key", value);
  else if (value is int)
    prefs.setInt("$key", value);
  else if (value is double)
    prefs.setDouble("$key", value);
  else if (value is String)
    prefs.setString("$key", value);
  else if (value is List) prefs.setStringList("$key", value);
}

Future<dynamic> _getValue(dynamic key) async =>
    (await SharedPreferences.getInstance()).get("$key");
