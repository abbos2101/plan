import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:toast/toast.dart';

Color kPrimaryColor = Colors.orangeAccent;
Color kGreenColor = Colors.green[400];
Color kRedColor = Colors.red[400];
Color kGreyColor = Colors.grey[300];

void toast(BuildContext context, dynamic s) => Toast.show("$s", context,
    duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);

void showMessage(BuildContext context) {
  double radius = 30;
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Center(
            child: Container(
              width: width / 1.2,
              height: height / 2.5,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(radius),
              ),
              child: Column(
                children: <Widget>[
                  Expanded(
                      flex: 2,
                      child: Container(
                        width: double.infinity,
                        child: Column(children: <Widget>[
                          Expanded(
                            child: Icon(Icons.warning_amber_rounded,
                                color: Colors.white, size: width * 0.2),
                          ),
                          Expanded(
                              child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              "Ohiriga yetmagan",
                              style:
                                  TextStyle(color: Colors.white, fontSize: 25),
                            ),
                          )),
                        ]),
                        decoration: BoxDecoration(
                          color: Colors.redAccent,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(radius),
                            topRight: Radius.circular(radius),
                          ),
                        ),
                      )),
                  Expanded(
                    flex: 3,
                    child: Container(
                        child: Image.asset("assets/image_error.png"),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(radius),
                              bottomRight: Radius.circular(radius)),
                        )),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );
}

void setSystemUI(bool showBar) async {
  await Future.delayed(Duration.zero);
  SystemChrome.setEnabledSystemUIOverlays(
    showBar == true ? SystemUiOverlay.values : [],
  );
}

double width = double.infinity;
double height = double.infinity;
