import 'package:flutter/material.dart';
import 'package:new_mano/module/util/const.dart';
import 'package:new_mano/screen/auth/registration/registration_screen.dart';
import 'package:new_mano/screen/main/index/main_screen.dart';
import 'package:new_mano/module/component/components.dart';
import 'package:new_mano/module/net/api.dart' as api;
import 'package:new_mano/module/pref/main_pref.dart' as pref;

class LoginPresenter {
  final BuildContext context;
  final Function onChanged;

  LoginPresenter(this.context, this.onChanged) {
    controllerUsername = TextEditingController();
    controllerPassword = TextEditingController();
  }

  TextEditingController controllerUsername;
  TextEditingController controllerPassword;
  bool enableButtonLogin = true;
  CView visibleLoading = CView.INVISIBLE;

  void onPressedLogin() async {
    FocusScope.of(context).requestFocus(FocusNode());
    String userName = controllerUsername.text.trim();
    String password = controllerPassword.text.trim();
    if (userName.isEmpty || password.isEmpty) {
      toast(context, "не хватает информации");
      return;
    }

    _loadingVisible(true);
    bool isFinished = await api.onLogin(username: userName, password: password);
    if (isFinished) {
      controllerUsername.text = "";
      controllerPassword.text = "";
      await pref.setPassedWelcome(true);
      Navigator.pushReplacement(context, MainScreen.route());
    } else
      toast(context, "Произошла ошибка");
    _loadingVisible(false);
  }

  void _loadingVisible(bool visible) {
    if (visible == true) {
      enableButtonLogin = false;
      visibleLoading = CView.VISIBLE;
    } else {
      enableButtonLogin = true;
      visibleLoading = CView.INVISIBLE;
    }
    onChanged();
  }

  void onPressedSignUp() {
    Navigator.push(context, RegistrationScreen.route());
  }
}
