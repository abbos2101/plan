import 'package:flutter/material.dart';
import 'login_presenter.dart';
import 'package:new_mano/module/component/components.dart';

class LoginScreen extends StatefulWidget {
  static PageRoute route() =>
      MaterialPageRoute(builder: (context) => LoginScreen());

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  LoginPresenter _presenter;

  @override
  void initState() {
    _presenter = LoginPresenter(context, () => setState(() {}));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CText("Ma'no", margin: EdgeInsets.all(40)),
              CTextField(
                controller: _presenter.controllerUsername,
                hint: "Foydalanuvchi nomi",
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 10),
              ),
              CTextField(
                controller: _presenter.controllerPassword,
                hint: "Maxfiy so'z",
                obscureText: true,
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 20),
              ),
              CButton(
                width: double.infinity,
                enable: _presenter.enableButtonLogin,
                onPressed: _presenter.onPressedLogin,
                child: Text("Kirish",
                    style: TextStyle(fontSize: 17, color: Colors.white)),
                circular: 10,
                margin: EdgeInsets.only(bottom: 50, left: 20, right: 20),
              ),
              CText(
                "Siz oldin ro'yxatdan o'tmaganmisiz?",
                style: TextStyle(fontSize: 14, color: Colors.black),
                margin: EdgeInsets.only(bottom: 15),
              ),
              CButton(
                width: double.infinity,
                child: Text("Ro'yxatdan o'tish",
                    style: TextStyle(fontSize: 17, color: Colors.white)),
                color: Colors.green,
                onPressed: _presenter.onPressedSignUp,
                circular: 10,
                margin: EdgeInsets.only(bottom: 50, left: 20, right: 20),
              ),
              CLoading(visibility: _presenter.visibleLoading),
            ],
          ),
        ),
      ),
    );
  }
}
