import 'package:flutter/material.dart';
import 'package:new_mano/module/util/const.dart';
import '../../screens.dart';
import 'package:new_mano/module/component/components.dart';
import 'package:new_mano/module/net/api.dart' as api;

class RegistrationPresenter {
  final BuildContext context;
  final Function onChanged;

  RegistrationPresenter(this.context, this.onChanged) {
    controllerUsername = TextEditingController();
    controllerFirstName = TextEditingController();
    controllerLastName = TextEditingController();
    controllerPassword = TextEditingController();
    controllerPasswordConfirm = TextEditingController();
  }

  TextEditingController controllerUsername;
  TextEditingController controllerFirstName;
  TextEditingController controllerLastName;
  TextEditingController controllerPassword;
  TextEditingController controllerPasswordConfirm;
  bool enableButtonLogin = true;
  CView visibleLoading = CView.INVISIBLE;

  void onPressedButton() async {
    FocusScope.of(context).requestFocus(FocusNode());
    String userName = controllerUsername.text.trim();
    String firstName = controllerFirstName.text.trim();
    String lastName = controllerLastName.text.trim();
    String password = controllerPassword.text.trim();
    String passwordConfirm = controllerPasswordConfirm.text.trim();
    if (userName.isEmpty ||
        firstName.isEmpty ||
        lastName.isEmpty ||
        password.isEmpty ||
        passwordConfirm.isEmpty) {
      toast(context, "не хватает информации");
      return;
    }

    _loadingVisible(true);
    bool isFinished = await api.onSignUp(
      firstname: firstName,
      lastname: lastName,
      username: userName,
      password: password,
      confirm_password: passwordConfirm,
    );
    if (isFinished) {
      toast(context, "Успешное создание учетной записи");
      Navigator.pushReplacement(context, WelcomeScreen.route());
    } else
      toast(context, "Произошла ошибка");
    _loadingVisible(false);
  }

  void _loadingVisible(bool visible) {
    if (visible == true) {
      enableButtonLogin = false;
      visibleLoading = CView.VISIBLE;
    } else {
      enableButtonLogin = true;
      visibleLoading = CView.INVISIBLE;
    }
    onChanged();
  }
}
