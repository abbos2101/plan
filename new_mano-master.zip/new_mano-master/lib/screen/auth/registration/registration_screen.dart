import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'registration_presenter.dart';
import 'package:new_mano/module/component/components.dart';

class RegistrationScreen extends StatefulWidget {
  static Route route() =>
      MaterialPageRoute<void>(builder: (_) => RegistrationScreen());

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  RegistrationPresenter _presenter;

  @override
  void initState() {
    _presenter = RegistrationPresenter(context, () => setState(() {}));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              CText("Ro'yxatdan o'tish", margin: EdgeInsets.only(bottom: 40)),
              CTextField(
                hint: "Login",
                controller: _presenter.controllerUsername,
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 10),
              ),
              CTextField(
                hint: "Ism",
                textCapitalization: TextCapitalization.words,
                controller: _presenter.controllerFirstName,
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 10),
              ),
              CTextField(
                hint: "Familiya",
                textCapitalization: TextCapitalization.words,
                controller: _presenter.controllerLastName,
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 10),
              ),
              CTextField(
                hint: "Parol",
                obscureText: true,
                controller: _presenter.controllerPassword,
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 10),
              ),
              CTextField(
                hint: "Parolni tasdiqlang",
                obscureText: true,
                controller: _presenter.controllerPasswordConfirm,
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 10),
              ),
              CButton(
                width: double.infinity,
                circular: 10,
                enable: _presenter.enableButtonLogin,
                onPressed: _presenter.onPressedButton,
                child: Text("Ro'yxatdan o'tish",
                    style: TextStyle(fontSize: 17, color: Colors.white)),
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 10),
              ),
              CLoading(visibility: _presenter.visibleLoading),
            ],
          ),
        ),
      ),
    );
  }
}
