import 'package:flutter/material.dart';
import 'package:new_mano/module/util/const.dart' as cons;
import 'package:new_mano/screen/auth/login/login_screen.dart';
import '../pages/lesson/index/lesson_screen.dart';
import '../pages/list/list_screen.dart';
import '../pages/folder/folder_screen.dart';
import '../pages/settings/setting_screen.dart';

class MainPresenter {
  BuildContext context;
  Function onChanged;
  bool showBar = true;

  MainPresenter(this.context, this.onChanged);

  List<Widget> bodies = [
    LessonScreen(),
    ListScreen(),
    FolderScreen(),
    SettingsScreen(),
  ];

  int bottomNavigationId = 0;

  void onPressedBottomNavigation(int id) {
    if (id == 3) {
      Navigator.pushReplacement(context, LoginScreen.route());
      return;
    }
    bottomNavigationId = id;
    onChanged();
  }
}
