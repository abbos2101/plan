import 'package:flutter/material.dart';
import 'main_presenter.dart';
import 'package:new_mano/module/component/components.dart';
import 'package:new_mano/module/util/const.dart' as cons;

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();

  static Route route() => MaterialPageRoute<void>(builder: (_) => MainScreen());
}

class _MainScreenState extends State<MainScreen> {
  MainPresenter presenter;

  @override
  void initState() {
    presenter = MainPresenter(context, () => setState(() {}));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    cons.setSystemUI(true);
    return CExitAppDialog(
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: presenter.bodies[presenter.bottomNavigationId],
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: presenter.bottomNavigationId,
            onTap: (id) => presenter.onPressedBottomNavigation(id),
            selectedItemColor: Colors.black,
            unselectedItemColor: Colors.black38,
            type: BottomNavigationBarType.fixed,
            iconSize: 30,
            showSelectedLabels: false,
            showUnselectedLabels: false,
            items: <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                  icon: Icon(Icons.assignment_turned_in_outlined),
                  label: "lesson"),
              BottomNavigationBarItem(
                  icon: Icon(Icons.assignment_outlined), label: "list"),
              BottomNavigationBarItem(
                  icon: Icon(Icons.folder_open_rounded), label: "folder"),
              BottomNavigationBarItem(
                  icon: Icon(Icons.settings), label: "settings"),
            ],
          ),
        ),
      ),
    );
  }
}
