export 'index/content_screen.dart';
export 'words/words_screen.dart';
export 'regulars/regular_screen.dart';
