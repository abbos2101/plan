import 'package:flutter/material.dart';
import 'package:new_mano/module/util/const.dart' as cons;
import '../content.dart';

class ContentPresenter {
  final BuildContext context;
  final Function onChanged;
  final int index;

  ContentPresenter(this.context, this.onChanged,
      {this.index, this.textDescription}) {
    textTitle = "$index-dars";
  }

  String textTitle = "";
  String textDescription = "";
  bool isActiveWord = false;
  bool isActiveRegular = false;
  bool isActivePractise = false;

  void onPressedButtonExit() => Navigator.pop(context);

  void onPressedWord() async {
    isActiveWord =
        (await Navigator.push(context, WordsScreen.route(index)) as bool) ??
            false;
    onChanged();
  }

  void onPressedRegular() async {
    isActiveRegular =
        (await Navigator.push(context, RegularScreen.route(index)) as bool) ??
            false;
    onChanged();
  }

  void onPressedPractise() async {
    isActivePractise =
        (await Navigator.push(context, RegularScreen.route(index, isPrac: true))
                as bool) ??
            false;
    onChanged();
  }
}
