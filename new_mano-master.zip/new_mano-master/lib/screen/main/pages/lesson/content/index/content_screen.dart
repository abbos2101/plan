import 'dart:math';
import 'package:flutter/material.dart';
import 'package:new_mano/module/util/const.dart' as cons;
import 'package:new_mano/module/component/components.dart';
import 'content_presenter.dart';

class ContentScreen extends StatefulWidget {
  @override
  _ContentScreenState createState() => _ContentScreenState();

  static PageRoute route(int index, String description) => MaterialPageRoute(
      builder: (context) => ContentScreen(index ?? 0, description ?? ""));
  final int index;
  final String description;

  const ContentScreen(this.index, this.description);
}

class _ContentScreenState extends State<ContentScreen> {
  final Color backgroundColor = Colors.white;
  ContentPresenter presenter;

  @override
  void initState() {
    presenter = ContentPresenter(
      context,
      () => setState(() {}),
      index: widget.index,
      textDescription: widget.description,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    cons.setSystemUI(true);
    return SafeArea(
      child: Scaffold(
        backgroundColor: backgroundColor,
        floatingActionButton: Align(
          alignment: Alignment.bottomLeft,
          child: CButtonExit(
              margin: EdgeInsets.only(left: 40, bottom: 20),
              onPressed: presenter.onPressedButtonExit),
        ),
        body: Column(
          children: <Widget>[
            _widgetTitle(),
            Expanded(child: _widgetBody()),
          ],
        ),
      ),
    );
  }

  Widget _widgetTitle() => Container(
        height: cons.height * 0.2,
        padding: EdgeInsets.only(bottom: 10),
        alignment: Alignment.bottomCenter,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(presenter.textTitle,
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
            Text(presenter.textDescription,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w400))
          ],
        ),
      );

  Widget _widgetBody() {
    double size = cons.width / 2.2;
    return Container(
      width: double.infinity,
      height: double.infinity,
      margin: EdgeInsets.only(bottom: 140),
      alignment: Alignment.center,
      child: Stack(
        children: <Widget>[
          CButtonShape(
            size: size,
            width: size,
            active: presenter.isActiveWord,
            showShadow: true,
            color: Colors.orangeAccent,
            child: Text("So'zlar", style: TextStyle(fontSize: 30)),
            onPressed: presenter.onPressedWord,
            rotate: 120,
            margin: EdgeInsets.only(right: size),
          ),
          CButtonShape(
            size: size,
            width: size,
            active: presenter.isActiveRegular,
            showShadow: true,
            color: Colors.orangeAccent,
            child: Text("Qoida", style: TextStyle(fontSize: 30)),
            onPressed: presenter.onPressedRegular,
            rotate: -120,
            margin: EdgeInsets.only(left: size),
          ),
          CButtonShape(
            size: size,
            width: size,
            active: presenter.isActivePractise,
            showShadow: true,
            color: Colors.orangeAccent,
            child: Text("Mashq", style: TextStyle(fontSize: 30)),
            onPressed: presenter.onPressedPractise,
            rotate: 0,
            margin: EdgeInsets.only(top: size * 0.86, left: size * 0.5),
          ),
          Padding(
            padding: EdgeInsets.only(top: size * 0.5, left: size * 0.75),
            child: Transform.rotate(
                angle: pi * 0.5,
                child: Container(
                    height: 5, width: size * 0.5, color: Colors.black)),
          ),
          Padding(
            padding: EdgeInsets.only(top: size * 0.91, left: size * 0.5),
            child: Transform.rotate(
                angle: pi * 0.82,
                child: Container(
                    height: 5, width: size * 0.5, color: Colors.black)),
          ),
          Padding(
            padding: EdgeInsets.only(top: size * 0.91, left: size),
            child: Transform.rotate(
                angle: pi * 0.18,
                child: Container(
                    height: 5, width: size * 0.5, color: Colors.black)),
          ),
          Container(
              width: 20,
              height: 20,
              margin: EdgeInsets.only(left: size * 0.95, top: size * 0.72),
              decoration:
                  BoxDecoration(color: Colors.black, shape: BoxShape.circle))
        ],
      ),
    );
  }
}
