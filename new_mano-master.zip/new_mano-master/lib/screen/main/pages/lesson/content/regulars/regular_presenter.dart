import 'package:flutter/material.dart';
import 'package:new_mano/module/component/components.dart';

class RegularPresenter {
  final BuildContext context;
  final Function onChanged;

  RegularPresenter(this.context, this.onChanged);

  int bodyCurrent = 0;
  bool bodyAnswer;
  bool isEnabledButtonSelect = false;

  String dialogTitle = "Orqaga qaytish";
  String dialogMessage = "Natijalar o'chib ketadi. Orqaga qaytasizmi?";

  void onPressedItemAll(int index) {
    CRegularChild child = bodyList[bodyCurrent];
    if (child.wordsAll[index].isActive) {
      child.wordsAll[index].isActive = false;
      child.wordsCheck.add(child.wordsAll[index]);
    }
    isEnabledButtonSelect = child.wordsCheck.length > 0;
    onChanged();
  }

  void onPressedItemCheck(int index) {
    CRegularChild child = bodyList[bodyCurrent];
    for (int i = 0; i < child.wordsAll.length; i++)
      if (child.wordsAll[i].text == child.wordsCheck[index].text) {
        child.wordsAll[i].isActive = true;
        break;
      }
    child.wordsCheck.removeAt(index);
    isEnabledButtonSelect = child.wordsCheck.length > 0;
    onChanged();
  }

  void onPressedButtonSelect() async {
    String s = "";
    for (int i = 0; i < bodyList[bodyCurrent].wordsCheck.length; i++)
      s += bodyList[bodyCurrent].wordsCheck[i].text + " ";
    bodyAnswer = s.trim() == bodyList[bodyCurrent].answer;
    isEnabledButtonSelect = false;
    onChanged();
    await Future.delayed(Duration(seconds: 1));
    if (bodyList.length - 1 == bodyCurrent) {
      Navigator.pop(context, true);
      return;
    }
    bodyAnswer = null;
    bodyCurrent++;
    onChanged();
  }

  void onPressedButtonExit() => showMyDialog(context);

  void onPressedDialogYes() {
    Navigator.pop(context);
    Navigator.pop(context);
  }

  Future<void> showMyDialog(BuildContext context) => showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(dialogTitle),
          content: Text(dialogMessage),
          actions: <Widget>[
            FlatButton(
              child: Text("Ha"),
              onPressed: onPressedDialogYes,
            ),
            FlatButton(
              child: Text("Yo'q"),
              onPressed: () => Navigator.of(context).pop(),
            )
          ],
        );
      });

  List<CRegularChild> bodyList = [
    CRegularChild(
      text: "Men shuyerda ishlayman",
      answer: "Мы работаю здесь",
      wordsAll: [
        CRegularWordsChild(text: "Мы", color: Colors.orangeAccent),
        CRegularWordsChild(text: "работаю", color: Colors.redAccent),
        CRegularWordsChild(text: "здесь", color: Colors.grey),
      ],
      wordsCheck: [],
    ),
    CRegularChild(
      text: "Ular shuyerda ishlaydi",
      answer: "Они работают здесь",
      wordsAll: [
        CRegularWordsChild(text: "Они", color: Colors.orangeAccent),
        CRegularWordsChild(text: "работают", color: Colors.redAccent),
        CRegularWordsChild(text: "здесь", color: Colors.grey),
      ],
      wordsCheck: [],
    ),
    CRegularChild(
      text: "Siz qahvani yoqtirasiz",
      answer: "Вы любите кофе",
      wordsAll: [
        CRegularWordsChild(text: "Вы", color: Colors.orangeAccent),
        CRegularWordsChild(text: "любите", color: Colors.redAccent),
        CRegularWordsChild(text: "кофе", color: Colors.grey),
      ],
      wordsCheck: [],
    ),
  ];
}
