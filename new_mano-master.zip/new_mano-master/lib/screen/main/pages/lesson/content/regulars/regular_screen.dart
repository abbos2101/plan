import 'package:flutter/material.dart';
import 'package:new_mano/module/util/const.dart' as cons;
import 'package:new_mano/module/component/components.dart';
import 'regular_presenter.dart';

class RegularScreen extends StatefulWidget {
  @override
  _RegularScreenState createState() => _RegularScreenState();

  static PageRoute route(int index, {bool isPrac = false}) =>
      MaterialPageRoute(builder: (_) => RegularScreen(index, isPrac: isPrac));
  final int index;
  final bool isPrac;

  const RegularScreen(this.index, {this.isPrac = false});
}

class _RegularScreenState extends State<RegularScreen> {
  RegularPresenter presenter;

  @override
  void initState() {
    presenter = RegularPresenter(context, () => setState(() {}));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    cons.setSystemUI(true);
    return CFinishOperationDialog(
      title: presenter.dialogTitle,
      message: presenter.dialogMessage,
      onPressedYes: presenter.onPressedDialogYes,
      child: SafeArea(
          child: Scaffold(
        backgroundColor: Colors.white,
        floatingActionButton: _widgetExitButton(),
        bottomSheet: _widgetCheck(),
        body: Container(
          margin: EdgeInsets.only(bottom: 120, top: 10, left: 10, right: 10),
          child: Column(
            children: [
              CProgressBarSimple(
                max: presenter.bodyList.length,
                progress: presenter.bodyCurrent,
              ),
              widget.isPrac == true
                  ? Container()
                  : Expanded(
                      flex: 1,
                      child: Container(
                        padding: EdgeInsets.all(10),
                        width: double.infinity,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text.rich(
                                TextSpan(children: [
                                  TextSpan(
                                    text: "Can",
                                    style: TextStyle(
                                        color: Colors.orangeAccent,
                                        fontSize: 18),
                                  ),
                                  TextSpan(
                                    text: " - могу или умею.",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 18),
                                  ),
                                  TextSpan(
                                    text: "\nУтверждение с can строится так:",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 18),
                                  ),
                                ]),
                              ),
                              Row(children: [
                                CButton(
                                  margin: EdgeInsets.all(5),
                                  height: 35,
                                  child: Text(
                                    "Ega",
                                    style: TextStyle(
                                        fontSize: 20, color: Colors.white),
                                  ),
                                ),
                                CText("+"),
                                CButton(
                                  margin: EdgeInsets.all(5),
                                  width: 60,
                                  color: Colors.grey[100],
                                  height: 35,
                                  child: Text(
                                    "...",
                                    style: TextStyle(
                                        fontSize: 20, color: Colors.black),
                                  ),
                                ),
                                CText("+"),
                                CButton(
                                  color: Colors.redAccent,
                                  margin: EdgeInsets.all(5),
                                  height: 35,
                                  child: Text(
                                    "Fe'l",
                                    style: TextStyle(
                                        fontSize: 20, color: Colors.white),
                                  ),
                                ),
                              ]),
                            ]),
                        margin: EdgeInsets.only(top: 20, bottom: 20),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          boxShadow: [
                            BoxShadow(color: Colors.black38, blurRadius: 10)
                          ],
                        ),
                      ),
                    ),
              Expanded(
                  flex: 3,
                  child: CRegularTest(
                      answer: presenter.bodyAnswer,
                      regularChild: presenter.bodyList[presenter.bodyCurrent],
                      onPressedAll: presenter.onPressedItemAll,
                      onPressedCheck: presenter.onPressedItemCheck)),
            ],
          ),
        ),
      )),
    );
  }

  Widget _widgetExitButton() => Align(
      alignment: Alignment.bottomLeft,
      child: CButtonExit(
        margin: EdgeInsets.only(left: 40, bottom: 20),
        onPressed: presenter.onPressedButtonExit,
      ));

  Widget _widgetCheck() => Container(
      height: 95,
      color: Colors.white,
      padding: EdgeInsets.only(bottom: 35),
      alignment: Alignment.bottomCenter,
      child: CButton(
        enable: presenter.isEnabledButtonSelect,
        circular: 10,
        width: 180,
        onPressed: presenter.onPressedButtonSelect,
        child: Text(
          "Tanlash",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ));
}
