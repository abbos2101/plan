import 'dart:math';
import 'package:flutter/material.dart';
import 'package:new_mano/module/component/components.dart';
import 'package:new_mano/module/util/const.dart';
import 'package:new_mano/module/net/api.dart' as api;

class WordsPresenter {
  final BuildContext context;
  final Function onChanged;
  final int index;

  WordsPresenter(this.context, this.onChanged, this.index) {
    setValue();
  }

  String dialogTitle = "Orqaga qaytish";
  String dialogMessage = "Natijalar o'chib ketadi. Orqaga qaytasizmi?";

  List<api.WordSectionModel> list;
  bool isLoading = false;
  CView cViewTest = CView.VISIBLE;
  String cardText = "";
  String questionText = "текст";
  List<String> answerTexts = ["", ""];
  int answer = 0;
  int current = 0;
  bool checkAnswer = true;

  Future<void> setValue() async {
    isLoading = true;
    onChanged();
    list = await api.onGetWordSection(index);
    isLoading = false;
    onNextQuestion();
    onChanged();
  }

  Future<void> showMyDialog(BuildContext context) => showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(dialogTitle),
          content: Text(dialogMessage),
          actions: <Widget>[
            FlatButton(
              child: Text("Ha"),
              onPressed: onPressedDialogYes,
            ),
            FlatButton(
              child: Text("Yo'q"),
              onPressed: () => Navigator.of(context).pop(),
            )
          ],
        );
      });

  void onPressedDialogYes() {
    Navigator.pop(context);
    Navigator.pop(context);
  }

  void onNextQuestion() {
    if (current == list.length - 1) {
      Navigator.pop(context, true);
      return;
    }
    questionText = list[current].correctWord.ru;
    cardText = list[current].correctWord.uz;
    int rand = Random().nextInt(2);
    answer = rand % 2;
    answerTexts[rand % 2] = list[current].correctWord.uz;
    answerTexts[(rand + 1) % 2] = list[current].incorrectWord.uz;
    current++;
  }

  void onPressedButtonNext() {
    cViewTest = CView.VISIBLE;
    onNextQuestion();
    onChanged();
  }

  Future<void> onPressedButtonAnswer(int id) async {
    cViewTest = CView.GONE;
    checkAnswer = id == answer;
    onChanged();
    await onPressedButtonCard();
  }

  Future<void> onPressedButtonCard() async {
    bool isPlayed =
        await api.onPlayMusic(list[current - 1].correctWord.soundName);
    if (isPlayed == false) toast(context, "xatolik");
  }

  void onPressedButtonExit() => showMyDialog(context);
}
