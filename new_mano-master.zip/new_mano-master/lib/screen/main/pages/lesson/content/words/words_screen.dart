import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_mano/module/component/components.dart';
import 'package:new_mano/module/util/const.dart' as cons;
import 'package:new_mano/module/component/components.dart';
import 'words_presenter.dart';

class WordsScreen extends StatefulWidget {
  @override
  _WordsScreenState createState() => _WordsScreenState();

  static PageRoute route(int index) =>
      MaterialPageRoute(builder: (_) => WordsScreen(index));
  final int index;

  const WordsScreen(this.index);
}

class _WordsScreenState extends State<WordsScreen> {
  WordsPresenter presenter;

  @override
  void initState() {
    presenter = WordsPresenter(context, () => setState(() {}), widget.index);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    cons.setSystemUI(true);
    return CFinishOperationDialog(
      title: presenter.dialogTitle,
      message: presenter.dialogMessage,
      onPressedYes: presenter.onPressedDialogYes,
      child: Scaffold(
        backgroundColor: Colors.white,
        floatingActionButton: _widgetExitButton(),
        body: Column(
          children: <Widget>[
            Expanded(flex: 3, child: _widgetTop()),
            Expanded(flex: 2, child: _widgetBottom()),
          ],
        ),
      ),
    );
  }

  Widget _widgetExitButton() => Align(
      alignment: Alignment.bottomLeft,
      child: CButtonExit(
        margin: EdgeInsets.only(left: 40, bottom: 20),
        onPressed: presenter.onPressedButtonExit,
      ));

  Widget _widgetTop() {
    return Column(
      children: <Widget>[
        Expanded(
          flex: 3,
          child: presenter.isLoading == false
              ? Image.asset("assets/welcome_image_test.png")
              : CLoading(),
        ),
        CText("Tarjimasini toping.", style: TextStyle(fontSize: 25)),
        CText(
          presenter.questionText,
          style: TextStyle(fontSize: 20, color: Colors.lightBlue),
        ),
        Expanded(flex: 1, child: SizedBox(width: double.infinity)),
      ],
    );
  }

  Widget _widgetBottom() {
    if (presenter.cViewTest == CView.VISIBLE)
      return Container(
        alignment: Alignment.bottomCenter,
        width: double.infinity,
        padding: EdgeInsets.only(bottom: 35),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CButton(
              enable: !presenter.isLoading,
              color: Colors.grey[200],
              width: 200,
              circular: 15,
              margin: EdgeInsets.only(bottom: 10),
              child: Text(presenter.answerTexts[0],
                  style: TextStyle(fontSize: 18)),
              onPressed: () => presenter.onPressedButtonAnswer(0),
            ),
            CButton(
              enable: !presenter.isLoading,
              color: Colors.grey[200],
              width: 200,
              circular: 15,
              child: Text(presenter.answerTexts[1],
                  style: TextStyle(fontSize: 18)),
              onPressed: () => presenter.onPressedButtonAnswer(1),
            ),
          ],
        ),
      );
    else
      return Container(
        alignment: Alignment.bottomCenter,
        width: double.infinity,
        padding: EdgeInsets.only(bottom: 35),
        child: Column(
          children: <Widget>[
            Expanded(
              child: CCardVoice(
                onPressed: presenter.onPressedButtonCard,
                width: double.infinity,
                circular: 30,
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 50),
                text: presenter.cardText,
                answer: presenter.checkAnswer,
              ),
            ),
            CButton(
              enable: !presenter.isLoading,
              color: Colors.orangeAccent,
              width: 200,
              circular: 15,
              child: Text("Keyingi", style: TextStyle(fontSize: 18)),
              onPressed: presenter.onPressedButtonNext,
            ),
          ],
        ),
      );
  }
}
