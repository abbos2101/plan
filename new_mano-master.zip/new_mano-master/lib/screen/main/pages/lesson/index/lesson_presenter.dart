import 'package:flutter/material.dart';
import 'package:new_mano/module/pref/main_pref.dart' as pref;
import 'package:new_mano/module/net/api.dart' as api;
import '../content/index/content_screen.dart';
import 'page1_vars.dart' as vars;

class LessonPresenter {
  BuildContext context;
  Function onChanged;

  LessonPresenter(this.context, this.onChanged) {
    _setValue();
  }

  void _setValue() async {
    vars.pageController = PageController(
      initialPage: vars.pageIndex,
      viewportFraction: 0.8,
    );
    if (vars.listLessons == null) vars.listLessons = await api.onGetLessons();
    if (vars.textLevel == null)
      vars.textLevel = "Level " + (await pref.level).toString();
    if (vars.textTheme == null) vars.textTheme = "00:00:00";
    onChanged();
  }

  void onChangedPage(int id) {
    vars.pageIndex = id;
    onChanged();
  }

  void onPressedButtonStart(int index) async {
    String description = vars.listLessons[index].name;
    description = description.substring(0, description.indexOf("."));
    await Navigator.push(context, ContentScreen.route(index + 1, description));

    ///onChanged();
  }
}
