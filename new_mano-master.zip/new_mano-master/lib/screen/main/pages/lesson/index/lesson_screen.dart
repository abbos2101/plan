import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'lesson_presenter.dart';
import 'package:new_mano/module/component/components.dart';
import 'page1_vars.dart' as vars;
import 'package:new_mano/module/util/const.dart' as cons;

class LessonScreen extends StatefulWidget {
  @override
  _LessonScreenState createState() => _LessonScreenState();

  static Route route() =>
      MaterialPageRoute<void>(builder: (_) => LessonScreen());
}

class _LessonScreenState extends State<LessonScreen> {
  LessonPresenter presenter;

  @override
  void initState() {
    presenter = LessonPresenter(context, () => setState(() {}));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    cons.setSystemUI(true);
    return Scaffold(
      backgroundColor: Colors.white,
      body: vars.listLessons == null
          ? CLoading()
          : Column(
              children: <Widget>[
                Expanded(flex: 3, child: _widgetTitle()),
                Expanded(flex: 10, child: _widgetPageView()),
                Expanded(flex: 1, child: _widgetPageProgress()),
              ],
            ),
    );
  }

  Widget _widgetTitle() => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            "${vars.textLevel}",
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 25),
          ),
          Text(
            "${vars.textTheme}",
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 30),
          ),
        ],
      );

  Widget _widgetPageView() => PageView.builder(
        itemBuilder: (context, index) {
          String title = vars.listLessons[index].blockName;
          String description = vars.listLessons[index].name;
          title = title.substring(0, title.indexOf("."));
          description = description.substring(0, description.indexOf("."));
          return CPageItem(
            onPressed: () => presenter.onPressedButtonStart(index),
            textTitle: "$title",
            textLesson: "${index + 1}-dars",
            textDescription: "$description",
            margin: EdgeInsets.only(right: 20, bottom: 20),
            imageUrl: vars.images[index],
          );
        },
        onPageChanged: (id) => presenter.onChangedPage(id),
        controller: vars.pageController,
        itemCount: vars.listLessons.length,
      );

  Widget _widgetPageProgress() => CPageProgress(
        itemCount: vars.listLessons.length,
        itemIndex: vars.pageIndex,
        itemMargin: EdgeInsets.all(2),
      );
}
