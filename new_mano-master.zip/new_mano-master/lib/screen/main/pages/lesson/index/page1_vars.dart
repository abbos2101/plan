import 'package:flutter/material.dart';
import 'package:new_mano/module/net/api.dart' as api;

List<api.LessonModel> listLessons;
String textLevel;
String textTheme;
int pageIndex = 0;
PageController pageController;
List<String> images = [
  "https://i.ytimg.com/vi/t4cyjka7xjU/hqdefault.jpg",
  "https://sites.google.com/site/priklucenialuntikaiegodruzej/_/rsrc/1459708556608/personazi-1/pceleenok/3ti3wbfu.jpg?height=326&width=400",
  "https://s1.dmcdn.net/v/CawZ41MQQ5a_iIfvn/x1080",
  "https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk_cqYhObNxETqr2X-_lxEP6aKTM5SRkZCeTgDn6uOyic",
  "https://static.wikia.nocookie.net/luntik/images/8/87/I9eq9ojyc0t9_2.jpg/revision/latest?cb=20150216204052&path-prefix=ru",
  "https://static.wikia.nocookie.net/luntik/images/b/b7/Images.jpg/revision/latest?cb=20160220190618&path-prefix=ru",
  "https://static.wikia.nocookie.net/luntik/images/8/87/I9eq9ojyc0t9_2.jpg/revision/latest?cb=20150216204052&path-prefix=ru",
];
