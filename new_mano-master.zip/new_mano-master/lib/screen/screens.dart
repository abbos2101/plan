//auth
export 'auth/login/login_screen.dart';
export 'auth/registration/registration_screen.dart';

export 'main/main.dart'; //main
export 'splash/splash_screen.dart'; //splash

//welcome
export 'welcome/result/welcome_result_screen.dart';
export 'welcome/test/welcome_test_screen.dart';
