import 'package:flutter/material.dart';
import '../screens.dart';
import 'package:new_mano/module/pref/main_pref.dart' as pref;

class SplashPresenter {
  final BuildContext context;
  final Function onChanged;

  const SplashPresenter(this.context, this.onChanged);

  Future<void> onNextScreen() async {
    await Future.delayed(Duration(seconds: 2));
    if (await pref.hasUser == false) {
      Navigator.pushReplacement(context, LoginScreen.route());
      return;
    }
    if (await pref.passedWelcome == false) {
      Navigator.pushReplacement(context, WelcomeScreen.route());
      return;
    }
    Navigator.pushReplacement(context, MainScreen.route());
  }
}
