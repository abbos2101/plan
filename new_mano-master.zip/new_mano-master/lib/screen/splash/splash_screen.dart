import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'splash_presenter.dart';
import 'package:new_mano/module/util/const.dart' as cons;

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  SplashPresenter _presenter;

  @override
  void initState() {
    super.initState();
    _presenter = new SplashPresenter(context, () => setState(() {}));
    _presenter.onNextScreen();
  }

  @override
  Widget build(BuildContext context) {
    cons.width = MediaQuery.of(context).size.width;
    cons.height = MediaQuery.of(context).size.height;
    SystemChrome.setEnabledSystemUIOverlays([]);
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          Expanded(child: _widgetBodyTop()),
          Expanded(child: _widgetBodyBottom()),
        ],
      ),
    );
  }

  Widget _widgetBodyTop() => Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
                gradient: new LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFDCE4F9), Color(0xFFFFFFFF)],
            )),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            margin: EdgeInsets.only(bottom: 20),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  "ma'no",
                  style: TextStyle(fontSize: 50, fontWeight: FontWeight.bold),
                ),
                Padding(
                    padding: EdgeInsets.only(bottom: 40),
                    child: Image.asset("assets/splash_bee.png"))
              ],
            ),
          ),
        ],
      );

  Widget _widgetBodyBottom() => Container(
        width: double.infinity,
        child: Image.asset(
          "assets/splash_body.png",
          fit: BoxFit.cover,
        ),
      );
}
