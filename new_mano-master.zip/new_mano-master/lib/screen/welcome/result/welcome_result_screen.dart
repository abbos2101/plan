import 'package:flutter/material.dart';
import 'package:new_mano/screen/main/main.dart';
import 'package:new_mano/module/pref/main_pref.dart' as pref;

class WelcomeResultScreen extends StatefulWidget {
  static Route route() =>
      MaterialPageRoute(builder: (_) => WelcomeResultScreen());

  @override
  _WelcomeResultScreenState createState() => _WelcomeResultScreenState();
}

class _WelcomeResultScreenState extends State<WelcomeResultScreen> {
  int level = 1;
  String levelName = "Элементарный";

  @override
  void initState() {
    super.initState();
    onNextScreen();
  }

  Future<void> onNextScreen() async {
    level = await pref.level;
    levelName = await pref.levelName;
    await pref.setPassedWelcome(true);
    await pref.setLevel(1);

    ///TODO delete this line
    await Future.delayed(Duration(seconds: 1));
    Navigator.pushReplacement(context, MainScreen.route());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: _widgetResult(level, levelName),
    );
  }

  Widget _widgetResult(int level, String levelName) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          margin: EdgeInsets.all(10),
          alignment: Alignment.center,
          height: height * 0.6,
          child: Stack(
            children: <Widget>[
              Center(
                child: Image.asset(
                  "assets/welcome_result.png",
                ),
              ),
              Center(
                child: Padding(
                  padding: EdgeInsets.only(bottom: width * 0.15),
                  child: Text("$level",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: width * 0.2,
                        fontWeight: FontWeight.w400,
                      )),
                ),
              ),
            ],
          ),
        ),
        Text(levelName,
            style: TextStyle(
              color: Colors.black,
              fontSize: width * 0.08,
              fontWeight: FontWeight.w400,
            )),
      ]),
    );
  }
}
