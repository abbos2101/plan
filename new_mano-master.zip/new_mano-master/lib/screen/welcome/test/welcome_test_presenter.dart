import 'package:flutter/material.dart';
import 'package:new_mano/module/net/api.dart' as api;
import 'package:new_mano/module/pref/main_pref.dart' as pref;
import '../../screens.dart';

class WelcomePresenter {
  final BuildContext context;
  final Function onChanged;

  WelcomePresenter(this.context, this.onChanged) {
    _loadNextLevel();
  }

  int currentLevel = 1;
  List<api.EntryModel> cardQuestions = [];
  List<api.LevelModel> levelItems = [];
  List<int> progressAnswers = [];
  int progressCurrent = 0;
  bool enableButton = false;
  int answerTrue = 0;
  int answerFalse = 0;

  void onPressedButtonTrue() async {
    await ss(buttonType: true);
  }

  void onPressedButtonFalse() async {
    await ss(buttonType: false);
  }

  void onOnPressedExit() =>
      Navigator.pushReplacement(context, LoginScreen.route());

  void onPressedIDontKnow() async {
    await ss(buttonType: null);
  }

  Future<void> ss({bool buttonType}) async {
    _checkQuestion(buttonType: buttonType);
    if (_getAnswersCount(answerType: false) + _getAnswersCount() >= 3) {
      _nextScreen(type: false);
      return;
    }
    if (_getAnswersCount(answerType: true) == 8) {
      if (currentLevel == levelItems.length) {
        _nextScreen(type: true);
        return;
      }
      await _loadNextLevel();
      return;
    }
    onChanged();
  }

  void _nextScreen({bool type = false}) async {
    int level = 1;
    String levelName = levelItems[0].name;
    if (type == false) {
      level = currentLevel != 1 ? currentLevel - 1 : 1;
      levelName = currentLevel != 1
          ? levelItems[currentLevel - 2].name
          : levelItems[0].name;
    } else {
      level = currentLevel;
      levelName = levelItems[currentLevel - 1].name;
    }
    await pref.setLevel(level);
    await pref.setLevelName(levelName);
    await pref.setPassedWelcome(true);
    Navigator.pushReplacement(context, WelcomeResultScreen.route());
  }

  void _checkQuestion({bool buttonType}) {
    if (progressCurrent >= progressAnswers.length) return;
    if (_getAnswersCount(answerType: false) + _getAnswersCount() >= 3) return;

    bool answer = cardQuestions[progressCurrent].answer;
    if (buttonType == null)
      progressAnswers[progressCurrent] = 0;
    else if (buttonType == answer)
      progressAnswers[progressCurrent] = 1;
    else if (buttonType != answer) progressAnswers[progressCurrent] = -1;
    progressCurrent++;
  }

  int _getAnswersCount({bool answerType}) {
    int count = 0;
    int checkNumber = 1;
    if (answerType == false)
      checkNumber = -1;
    else if (answerType == null) checkNumber = 0;
    for (int i = 0; i < progressCurrent; i++) {
      if (progressAnswers[i] == checkNumber) count++;
    }
    return count;
  }

  Future<void> _loadNextLevel() async {
    if (currentLevel == 1) levelItems = await api.onGetLevelList();
    progressCurrent = 0;
    progressAnswers.clear();
    if (currentLevel == levelItems.length) return;
    enableButton = false;
    onChanged();

    cardQuestions = await api.onGetEntryQuestions(currentLevel);
    for (int i = 0; i < cardQuestions.length; i++) progressAnswers.add(0);
    enableButton = true;
    currentLevel++;
    onChanged();
  }
}
