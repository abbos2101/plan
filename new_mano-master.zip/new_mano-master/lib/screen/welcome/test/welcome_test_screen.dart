import 'package:flutter/material.dart';
import 'welcome_test_presenter.dart';
import 'package:new_mano/module/component/components.dart';

class WelcomeScreen extends StatefulWidget {
  static Route route() => MaterialPageRoute(builder: (_) => WelcomeScreen());

  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  WelcomePresenter _presenter;

  @override
  void initState() {
    _presenter = WelcomePresenter(context, () => setState(() {}));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          Expanded(
            flex: 1,
            child: CProgressBar(
              anwers: _presenter.progressAnswers,
              index: _presenter.progressCurrent,
              itemSize: width * 0.1,
            ),
          ),
          Expanded(
            flex: 3,
            child: CCardTest(
              height: height,
              enableButton: _presenter.enableButton,
              question: _presenter.cardQuestions.length != 0
                  ? _presenter
                      .cardQuestions[_presenter.progressCurrent].question
                  : "Загрузка ...",
              onPressedTrue: _presenter.onPressedButtonTrue,
              onPressedFalse: _presenter.onPressedButtonFalse,
            ),
          ),
        ],
      ),
      bottomSheet: Container(
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            CButtonExit(
              margin: EdgeInsets.all(20),
              onPressed: _presenter.onOnPressedExit,
              visibility: CView.GONE,
            ),
            CButton(
              margin: EdgeInsets.all(20),
              onPressed: _presenter.onPressedIDontKnow,
              enable: _presenter.enableButton,
              child: Text(
                "Javobini\nbilmayman",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              width: 160,
              height: 60,
              circular: 20,
            ),
          ],
        ),
      ),
    );
  }
}
